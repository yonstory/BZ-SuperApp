package com.yonstory.bzsuperapp;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

/** Opens BZ Super App in a Chrome Custom Tab so the phone's existing Google sign-in is used. */
public class MainActivity extends Activity {
    static final String URL = "https://bit.ly/BZSuperApp";
    static final int TOOLBAR = 0xFF0E2A47;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        open();
        finish();
    }

    private void open() {
        Uri uri = Uri.parse(URL);
        Intent tab = new Intent(Intent.ACTION_VIEW, uri);
        Bundle session = new Bundle();
        session.putBinder("android.support.customtabs.extra.SESSION", null);
        tab.putExtras(session);
        tab.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR", TOOLBAR);
        tab.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 1);
        tab.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 2);
        String pkg = pickBrowser();
        if (pkg != null) tab.setPackage(pkg);
        try {
            startActivity(tab);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception e2) {
                Toast.makeText(this, "Pasang Google Chrome untuk membuka BZ Super App", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String pickBrowser() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> services = pm.queryIntentServices(
                new Intent("android.support.customtabs.action.CustomTabsService"), 0);
        String first = null;
        for (ResolveInfo ri : services) {
            String p = ri.serviceInfo.packageName;
            if ("com.android.chrome".equals(p)) return p;
            if (first == null) first = p;
        }
        return first;
    }
}
